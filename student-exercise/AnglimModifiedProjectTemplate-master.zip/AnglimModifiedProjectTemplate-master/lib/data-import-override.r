# Add alternative data importation commands for files in 
# the data folder that should not be imported using standard data importation rules
